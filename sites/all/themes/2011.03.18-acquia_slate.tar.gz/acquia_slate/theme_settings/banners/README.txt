Banner images packaged with the Acquia Slate theme are credited to the following:

beachstone.jpg - by Sandy Caldwell
http://caldwellpics.com/

greek-heads.jpg - by Dries Buytaert
http://buytaert.net/

london-phone-booth.jpg - by Dries Buytaert
http://buytaert.net/

rope.jpg - by Dries Buytaert
http://buytaert.net/

view-from-room.jpg - by Dries Buytaert
http://buytaert.net/

wheat.jpg - by Dries Buytaert
http://buytaert.net/
